﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace UnitTestProject1
{
  
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod1()
        {
            string text = "DXC Technologies";
            IWebDriver driver;
            driver = new ChromeDriver("C:\\SeleniumJars");
            driver.Url = "https://www.google.com/";
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("/html/body/div/div[4]/form/div[2]/div[1]/div[1]/div/div[2]/input")).SendKeys(text);
            Thread.Sleep(3000);
            driver.FindElement(By.ClassName("gNO89b")).Click();
            Console.WriteLine(driver.Title);
            Console.WriteLine(driver.FindElement(By.XPath("/html/body/div[7]/div[3]/div[7]/div[1]/div/div/div/div")).Text);
            if((driver.Title).Contains(text))
            {
                Console.WriteLine("Pass");
            }
            else
            {
                Console.WriteLine("Fail");
            }
            driver.Close();
        }
    }

      
}
