﻿
using System;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest3
    {
        [TestMethod]
        public void TestMethod2()
        {
            String vURL = "http://www.youcandealwithit.com/";
            IWebDriver driver;
            driver = new FirefoxDriver("C:\\SeleniumJars");
            driver.Manage().Window.Maximize();
            driver.Url = vURL;
            Thread.Sleep(2000);

            Actions action = new Actions(driver);
            action.MoveToElement(driver.FindElement(By.XPath("/html/body/div[1]/ul[2]/li[1]/a"))).Build().Perform();
            driver.FindElement(By.LinkText("Calculators & Resources")).Click();
            Thread.Sleep(2000);
            String LT_CR = driver.FindElement(By.LinkText("Calculators & Resources")).Text;

            if (driver.Title.Contains(LT_CR))
            {
                driver.FindElement(By.LinkText("Calculators")).Click();
                Thread.Sleep(2000);
                String LT_C = driver.FindElement(By.LinkText("Calculators")).Text;

                if (driver.Title.Contains(LT_C))
                {
                    driver.FindElement(By.LinkText("Budget Calculator")).Click();
                    Thread.Sleep(2000);
                    String LT_BC = driver.FindElement(By.LinkText("Budget Calculator")).Text;
                    if (driver.Title.Contains(LT_BC))
                    {
                        driver.FindElement(By.Id("food")).SendKeys("1000");
                        driver.FindElement(By.Id("clothing")).SendKeys("1500");
                        driver.FindElement(By.Id("shelter")).SendKeys("4000");
                        driver.FindElement(By.Id("monthlyPay")).SendKeys("30000");
                        driver.FindElement(By.Id("monthlyOther")).SendKeys("5000");
                        double under = Double.Parse(driver.FindElement(By.Id("underOverBudget")).GetAttribute("value"));
                        Console.WriteLine("underover budget is " + under);

                        double monthlyexp = Double.Parse(driver.FindElement(By.Id("totalMonthlyExpenses")).GetAttribute("value"));
                        double monthlyp = Double.Parse(driver.FindElement(By.Id("monthlyPay")).GetAttribute("value"));
                        Console.WriteLine("total monthly expense is "+ monthlyexp);
                        Console.WriteLine("total monthly pay is " + monthlyp);
                        driver.Close();
                        Console.WriteLine("Test Case Successful");
                    }
                    else
                    {
                        Console.WriteLine("Test Case Failed at Budget Calculator Link");
                    }

                }
                else
                {
                    Console.WriteLine("Test Case Failed at Calculators Link");
                }
            }
            else
            {
                Console.WriteLine("Test Case Failed at Calculators & Resources Link");
            }

            
        }
    }
}
